@extends('layouts.app')

@section('content')

<div class="container">
    <div class="row justify-content-md-center">
        <div class="col-md-auto">
            <h2 class="text-center">My Profile</h2>
            <div class="card" style="width:400px">
                <img class="card-img-top" src="{{ asset('img/profile.jpg') }}" alt="Card image" style="width:100%">
                <div class="card-body">
                <h4 class="card-title text-center">{{$users->name}}</h4>
                <p class="card-text text-center">{{$users->user_dept_name}} @Meticulous</p>
                <p class="card-text text-center">{{$users->user_designation_name}}</p>
                <!-- <a href="#" class="btn btn-primary">Edit Profile</a> -->
                </div>
            </div>
        </div>
    </div>
</div>
@endsection


