<!DOCTYPE html>
<html lang="en">

<head>

	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<meta name="description" content="">
	<meta name="author" content="">

	<title>CRM - Login</title>

	<!-- Custom fonts for this template-->
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css" integrity="sha384-oS3vJWv+0UjzBfQzYUhtDYW+Pj2yciDJxpsK1OYPAYjqT085Qq/1cq5FLXAZQ7Ay" crossorigin="anonymous">

</head>

<body>

	<div class="container">

		<!-- Outer Row -->
		<div class="row justify-content-center">
			<div class="col-md-6">
				<div class="card o-hidden border-0 shadow-lg my-5 bg-default">
					<div class="card-body p-0">
						<!-- Nested Row within Card Body -->
							<div>
								<div class="p-5">
									<div class="text-center">
										<h1 class="h4 text-gray-900 mb-4">Welcome Back!</h1>
									</div>
									<form method="POST" class="user" action="{{ route('login') }}">
										{{ csrf_field() }}
										<div class="form-group">
											<input id="email" type="email" class="form-control" name="email" value="{{ old('email') }}" required autofocus>
											@if ($errors->has('email'))
											<span class="help-block">
												<strong>{{ $errors->first('email') }}</strong>
											</span>
											@endif
										</div>
										<div class="form-group">
											<input id="password" type="password" class="form-control" name="password" required>
											@if ($errors->has('password'))
											<span class="help-block">
												<strong>{{ $errors->first('password') }}</strong>
											</span>
											@endif
										</div>
										<button type="submit" class="btn btn-primary btn-user btn-block">
											{{ __('Login') }}
										</button>
										<div class="text-center">
											@if (Route::has('password.request'))
											<a class="small" href="{{ route('password.request') }}">
												{{ __('Forgot Your Password?') }}
											</a>
											@endif
										</div>
									</form>
								</div>
							</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</body>

</html>