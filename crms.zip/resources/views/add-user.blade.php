@extends('layouts.app')

@section('content')
<div class="container-fluid">
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h4 class="m-0 font-weight-bold text-primary">Add User</h6>
        </div>
        <div class="card-body">
            <div class="p-5">
                <form method="POST" class="user" action="{{ route('submitUser') }}" >
                    @if(count($errors))
                        <div class="alert alert-danger">
                            <strong>Whoops!</strong> There were some problems with your input.
                            <br/>
                            <ul>
                                @foreach($errors->all() as $error)
                                <li>{{ $error }}</li>
                                @endforeach
                            </ul>
                        </div>
                    @endif
                    <div class="form-group row">
                        <div class="col-sm-6 mb-3 mb-sm-0">
                            <div class="form-group {{ $errors->has('firstName') ? 'has-error' : '' }}"> 
                                <input type="text" name="firstName" class="form-control form-control-user" id="firstName" placeholder="First Name" value="{{ old('firstName') }}" required>
                                <span class="text-danger">{{ $errors->first('firstName') }}</span>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group {{ $errors->has('lastName') ? 'has-error' : '' }}"> 
                                <input type="text" class="form-control form-control-user" id="lastName" placeholder="Last Name" name="lastName" value="{{ old('lastName') }}" required>
                                <span class="text-danger">{{ $errors->first('lastName') }}</span>
                            </div>
                        </div>
                    </div>
                    <div class="form-group row">
                        <div class="col-sm-6 mb-3 mb-sm-0">
                            <div class="form-group {{ $errors->has('email') ? 'has-error' : '' }}"> 
                                <input type="email" class="form-control form-control-user" id="emailId" placeholder="Email Address" value="{{ old('email') }}" name="email" required>
                                <span class="text-danger">{{ $errors->first('email') }}</span>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group {{ $errors->has('employeeId') ? 'has-error' : '' }}">
                                <input type="text" class="form-control form-control-user" id="employeeId" placeholder="Employee Id" name="employeeId" value="{{ old('employeeId') }}" required>
                                <span class="text-danger">{{ $errors->first('employeeId') }}</span>
                            </div>
                        </div>
                    </div>
                    <div class="form-group row">
                        <div class="col-sm-6 mb-3 mb-sm-0">
                            <div class="form-group {{ $errors->has('departmentList') ? 'has-error' : '' }}">
                                <select class="form-control col-sm-12" name="departmentList" required>
                                    <option>Select Department</option>
                                    @foreach($userArray['departments'] as $departmentsList)
                                    <option  value="{{$departmentsList->DeptName}}">{{$departmentsList->DeptName}}</option>
                                    @endforeach
                                </select>
                                <span class="text-danger">{{ $errors->first('departmentList') }}</span>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group {{ $errors->has('designationsList') ? 'has-error' : '' }}">
                                <select class="form-control col-sm-12" name="designationsList" required>
                                    <option value="">Select Designation</option>
                                    @foreach($userArray['designations'] as $designationsList)
                                        <option value="{{$designationsList->designationName}}">{{$designationsList->designationName}}</option>
                                    @endforeach
                                </select>
                                <span class="text-danger">{{ $errors->first('designationsList') }}</span>
                            </div>
                        </div>
                    </div>
                    <div class="form-group row">
                        <div class="col-sm-6 mb-3 mb-sm-0">
                            <div class="form-group {{ $errors->has('regionsList') ? 'has-error' : '' }}">
                                <select id="regionsList" name="regionsList[]" multiple="multiple" class="form-control form-control-user" required>
                                    @foreach($userArray['regions'] as $regionsList)
                                        <option value="{{$regionsList->id}}">{{$regionsList->regionName}}</option>
                                    @endforeach
                                </select>
                                <span class="text-danger">{{ $errors->first('regionsList') }}</span>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group {{ $errors->has('categoriesList') ? 'has-error' : '' }}">
                                <select id="categoriesList" name="categoriesList[]" multiple="multiple" class="form-control form-control-user" required style="width:430px;">
                                    @foreach($userArray['categories'] as $categoriesList)
                                        <option value="{{$categoriesList->id}}">{{$categoriesList->categoryName}}</option>
                                    @endforeach
                                </select>
                                <span class="text-danger">{{ $errors->first('categoriesList') }}</span>
                            </div>
                        </div>
                    </div>
                    <button type="submit" class="btn btn-primary btn-user btn-block">Create User Account</button>
                    {{ csrf_field() }}
                </form>
            </div>
        </div>
    </div>
</div>
<link href="{{ asset('css/bootstrap-multiselect.css') }}" rel="stylesheet" type="text/css" />
<script src="{{ asset('js/bootstrap-multiselect.min.js') }}" type="application/javascript"></script>
<script type="application/javascript">
$(function () {
    $('#regionsList').multiselect({
        includeSelectAllOption: true
    });
});
$(function () {
    $('#categoriesList').multiselect({
        includeSelectAllOption: true,
    });
});
</script>
@endsection