@extends('layouts.app')

@section('content')
<div class="container-fluid">
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h4 class="m-0 font-weight-bold text-primary">Update User</h6>
        </div>
        <div class="card-body">
            <div class="p-5">
                <form method="POST" class="user" action="{{ route('updateUser') }}" >
                    @if(count($errors))
                        <div class="alert alert-danger">
                            <strong>Whoops!</strong> There were some problems with your input.
                            <br/>
                            <ul>
                                @foreach($errors->all() as $error)
                                <li>{{ $error }}</li>
                                @endforeach
                            </ul>
                        </div>
                    @endif
                    <input type="hidden" value="{{$userArray['userInfo']['id']}}" name="userId" />
                    <div class="form-group row">
                        <div class="col-sm-12 mb-3 mb-sm-0">
                            <div class="form-group {{ $errors->has('firstName') ? 'has-error' : '' }}"> 
                                <input type="text" name="firstName" class="form-control form-control-user" id="firstName" placeholder="First Name" value="{{$userArray['userInfo']['name']}}" required>
                                <span class="text-danger">{{ $errors->first('firstName') }}</span>
                            </div>
                        </div>
                    </div>
                    <div class="form-group row">
                        <div class="col-sm-6 mb-3 mb-sm-0">
                            <div class="form-group {{ $errors->has('email') ? 'has-error' : '' }}"> 
                                <input type="email" class="form-control form-control-user" id="emailId" placeholder="Email Address" value="{{$userArray['userInfo']['email']}}" name="email" required>
                                <span class="text-danger">{{ $errors->first('email') }}</span>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group {{ $errors->has('employeeId') ? 'has-error' : '' }}">
                                <input type="text" class="form-control form-control-user" id="employeeId" placeholder="Employee Id" name="employeeId" value="{{$userArray['userInfo']['userEmpId']}}" required>
                                <span class="text-danger">{{ $errors->first('employeeId') }}</span>
                            </div>
                        </div>
                    </div>
                    <div class="form-group row">
                        <div class="col-sm-6 mb-3 mb-sm-0">
                            <div class="form-group {{ $errors->has('departmentList') ? 'has-error' : '' }}">
                                <select class="form-control-user col-sm-12" name="departmentList" style="padding:0.9rem 1rem;" required>
                                    <option>Select Department</option>
                                    @foreach($userArray['departments'] as $departmentsList)
                                        @if($departmentsList->DeptName == $userArray['userInfo']['user_dept_name'])
                                            <option value="{{ $departmentsList->DeptName }}" selected>{{$departmentsList->DeptName}}</option>
                                        @else
                                            <option value="{{ $departmentsList->DeptName }}" >{{$departmentsList->DeptName}}</option>
                                        @endif
                                    @endforeach
                                </select>
                                <span class="text-danger">{{ $errors->first('departmentList') }}</span>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group {{ $errors->has('designationsList') ? 'has-error' : '' }}">
                                <select class="form-control-user col-sm-12" name="designationsList" style="padding:0.9rem 1rem;" required>
                                    <option value="">Select Designation</option>
                                    @foreach($userArray['designations'] as $designationsList)
                                        @if($designationsList->designationName == $userArray['userInfo']['user_designation_name'])
                                            <option value="{{$designationsList->designationName}}" selected>{{$designationsList->designationName}}</option>
                                        @else
                                            <option value="{{$designationsList->designationName}}">{{$designationsList->designationName}}</option>
                                        @endif
                                    @endforeach
                                </select>
                                <span class="text-danger">{{ $errors->first('designationsList') }}</span>
                            </div>
                        </div>
                    </div>
                    <div class="form-group row">
                        <div class="col-sm-6 mb-3 mb-sm-0">
                            <div class="form-group {{ $errors->has('regionsList') ? 'has-error' : '' }}">
                                <select id="regionsList" name="regionsList[]" multiple="multiple" class="form-control form-control-user" required>
                                    @foreach($userArray['regions'] as $regionsList)
                                        @if(in_array($regionsList->id, $userArray['userInfo']['userRegionId']))
                                            <option selected value="{{$regionsList->id}}">{{$regionsList->regionName}}</option>
                                        @else
                                            <option value="{{$regionsList->id}}">{{$regionsList->regionName}}</option>
                                        @endif    
                                    @endforeach
                                </select>
                                <span class="text-danger">{{ $errors->first('regionsList') }}</span>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group {{ $errors->has('categoriesList') ? 'has-error' : '' }}">
                                <select id="categoriesList" name="categoriesList[]" multiple="multiple" class="form-control form-control-user" required style="width:430px;">
                                    @foreach($userArray['categories'] as $categoriesList)
                                        @if(in_array($categoriesList->id, $userArray['userInfo']['userCategoryId']))
                                            <option value="{{$categoriesList->id}}" selected>{{$categoriesList->categoryName}}</option>
                                        @else
                                            <option value="{{$categoriesList->id}}">{{$categoriesList->categoryName}}</option>
                                        @endif    
                                    @endforeach
                                </select>
                                <span class="text-danger">{{ $errors->first('categoriesList') }}</span>
                            </div>
                        </div>
                    </div>
                    <button type="submit" class="btn btn-primary btn-user btn-block">Update User Account</button>
                    {{ csrf_field() }}
                </form>
            </div>
        </div>
    </div>
</div>
<link href="{{ asset('css/bootstrap-multiselect.css') }}" rel="stylesheet" type="text/css" />
<script src="{{ asset('js/bootstrap-multiselect.min.js') }}" type="application/javascript"></script>
<script type="application/javascript">
$(function () {
    $('#regionsList').multiselect({
        includeSelectAllOption: true
    });
});
$(function () {
    $('#categoriesList').multiselect({
        includeSelectAllOption: true,
    });
});
</script>
@endsection