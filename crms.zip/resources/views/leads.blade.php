@extends('layouts.app')

@section('content')
<div class="clearfix">&nbsp;</div>
@if(session()->get('success'))
<div class="alert alert-success my-2">
    {{ session()->get('success') }}
</div>
@endif
@if(session()->get('error'))
    <div class="alert alert-danger my-2">
        {{ session()->get('error') }}
    </div>
@endif
<div class="alert alert-success my-2" id="delete-msg" style="display:none;">
    
</div>

<div class="container-fluid">
    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h4 class="m-0 font-weight-bold text-primary">Leads Listing</h6>
        </div>
        <div class="card-body">
            <div>
                <table class="table table-bordered" id="leadslist">
                    <thead>
                    <tr>
                        <th>Lead Id</th>
                        <th>Lead Code</th>
                        <th>Report Title</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Company</th>
                        <th>Status</th>
                        <th>Stage</th>
                        <th>Action</th>
                    </tr>
                    </thead>
                </table>
            </div>
        </div>
    </div>
</div>

<div class="modal fade text-dark" id="delete-modal">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5>Do you really want to delete this User?</h5>
            </div>
            <div class="modal-footer justify-content-end">
                <button onclick="deleteUser('delete-modal');" class="btn btn-sm btn-success">Yes</button>
                <button onclick="closeModal('delete-modal')" class="btn btn-sm btn-danger ml-2">No</button>
            </div>
        </div>
    </div>
</div>
<div class="modal fade text-dark" id="edituser-modal">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5>Select Version:</h5>
                <button onclick="closeModal('edituser-modal')" class="btn btn-sm btn-danger float-right">X</button>
            </div>
            <div class="modal-body" id="edituser-body">
                
            </div>
        </div>
    </div>
</div>
@endsection

@section('custom-script')
<script src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.10.19/js/dataTables.bootstrap4.min.js"></script>
<script type="application/javascript">
    var userDeleteId = 0;
    var userActivateId = 0;
    var baseUrl = "{{ url('/')}}";


    $(document).ready(function(){
        getleads();
    }) 
    function getleads(){
        if (!$.fn.DataTable.isDataTable('#leadslist')) 
        {
            var dataTable=$('#leadslist').DataTable({
                "processing": true,
                "serverSide":true,
                "ajax":{
                    headers:
                    {
                        'X-CSRF-Token':"{{csrf_token()}}"
                    },
                    url:"{{ url('/getleadslist')}}",
                    type:"post"
                },
                "columnDefs": [
                { 
                    "targets": [8],
                    "orderable":false 
                }]
            });
        }
    }   
    function confirmDelete(id){
        userDeleteId = id;
        $('#delete-modal').modal('show');
        
    }
    function closeModal(id)
    {
        var modalId = '#'+id;
        $(modalId).modal('hide');
    } 
    function confirmEdit(id)
    {
        url = 'getUserInfo/'+id;
        window.location.href = '{{url("'+url+'")}}';
    }
    function deleteUser(modalId){
        $.ajax({
            headers:
            {
                'X-CSRF-Token': "{{csrf_token()}}"
            },
            type: "POST",
            url:"{{ url('/deleteUser') }}",
            data: {
                userId : userDeleteId
            },
            success:function(response){
                // console.log(response);
                closeModal(modalId);
                $('#delete-msg').html(response).show();
                $("#leadslist").dataTable().fnDestroy()
                getAllUsers();
                setTimeout(function() {
                    $('#delete-msg').fadeOut('slow');
                }, 3000);    
            }
        });
    }
</script> 
@endsection
       

