@extends('layouts.app')

@section('content')
    @if( Auth::user()->user_designation_name == 'Admin' || Auth::user()->user_designation_name == 'Manager')
        <div class="container-fluid">
            <a href="{{route('addUser')}}" class="btn btn-success btn-icon-split">
                <span class="icon text-white-50">
                    <i class="fas fa-user"></i>
                </span>
                <span class="text">Add Users</span>
            </a>
        </div>
    @endif
<div class="clearfix">&nbsp;</div>
@if(session()->get('success'))
<div class="alert alert-success my-2">
    {{ session()->get('success') }}
</div>
@endif
@if(session()->get('error'))
    <div class="alert alert-danger my-2">
        {{ session()->get('error') }}
    </div>
@endif
<div class="alert alert-success my-2" id="delete-msg" style="display:none;">
    
</div>

<div class="container-fluid">
    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h4 class="m-0 font-weight-bold text-primary">User Listing</h6>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="userList" width="100%" cellspacing="0">
                    <thead>
                    <tr>
                        <th>Id</th>
                        <th>Name</th>
                        <th>Email Id</th>
                        <th>Department</th>
                        <th>Position</th>
                        <th>Action</th>
                    </tr>
                    </thead>
                </table>
            </div>
        </div>
    </div>
</div>

<div class="modal fade text-dark" id="delete-modal">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5>Do you really want to delete this User?</h5>
            </div>
            <div class="modal-footer justify-content-end">
                <button onclick="deleteUser('delete-modal');" class="btn btn-sm btn-success">Yes</button>
                <button onclick="closeModal('delete-modal')" class="btn btn-sm btn-danger ml-2">No</button>
            </div>
        </div>
    </div>
</div>
<div class="modal fade text-dark" id="edituser-modal">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5>Select Version:</h5>
                <button onclick="closeModal('edituser-modal')" class="btn btn-sm btn-danger float-right">X</button>
            </div>
            <div class="modal-body" id="edituser-body">
                
            </div>
        </div>
    </div>
</div>
<link href="{{ asset('datatables/dataTables.bootstrap4.min.css') }}" rel="stylesheet">
<script type="application/javascript" src="{{ asset('datatables/jquery.dataTables.min.js') }}"></script>
<script type="application/javascript" src="{{ asset('datatables/dataTables.bootstrap4.min.js') }}"></script>
<script type="application/javascript" src="{{ asset('js/demo/datatables-demo.js') }}"></script>
<script type="application/javascript">
    var userDeleteId = 0;
    var userActivateId = 0;
    var baseUrl = "{{ url('/')}}";


    $(document).ready(function(){
        getAllUsers();
    }) 
    function getAllUsers(){
        if (!$.fn.DataTable.isDataTable('#userList')) 
        {
            var dataTable=$('#userList').DataTable({
                "processing": true,
                "serverSide":true,
                "ajax":{
                    headers:
                    {
                        'X-CSRF-Token':"{{csrf_token()}}"
                    },
                    url:"{{ url('/getUserList')}}",
                    type:"post"
                },
                "columnDefs": [
                { 
                    "targets": [ 4, 3, 2, 1, 0 ], 
                }]
            });
        }
    }   
    function confirmDelete(id){
        userDeleteId = id;
        $('#delete-modal').modal('show');
        
    }
    function closeModal(id)
    {
        var modalId = '#'+id;
        $(modalId).modal('hide');
    } 
    function confirmEdit(id)
    {
        url = 'getUserInfo/'+id;
        window.location.href = '{{url("'+url+'")}}';
    }
    function deleteUser(modalId){
        $.ajax({
            headers:
            {
                'X-CSRF-Token': "{{csrf_token()}}"
            },
            type: "POST",
            url:"{{ url('/deleteUser') }}",
            data: {
                userId : userDeleteId
            },
            success:function(response){
                // console.log(response);
                closeModal(modalId);
                $('#delete-msg').html(response).show();
                $("#userList").dataTable().fnDestroy()
                getAllUsers();
                setTimeout(function() {
                    $('#delete-msg').fadeOut('slow');
                }, 3000);    
            }
        });
    }
</script> 
@endsection
       

