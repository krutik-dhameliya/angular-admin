@extends('layouts.app')

@section('content')
<div class="container-fluid">
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h4 class="m-0 font-weight-bold text-primary">Add Invoice</h6>
        </div>
        <div class="card-body">
            <div class="p-5">
                <form method="POST" class="user" action="{{ route('updateUser') }}" >
                    @if(count($errors))
                        <div class="alert alert-danger">
                            <strong>Whoops!</strong> There were some problems with your input.
                            <br/>
                            <ul>
                                @foreach($errors->all() as $error)
                                <li>{{ $error }}</li>
                                @endforeach
                            </ul>
                        </div>
                    @endif
                    <input type="hidden" value="{{$data['lead_id']}}" name="lead_id" />
                    <input type="hidden" value="{{$data['report_id']}}" name="report_id" />
                    <div class="form-group row">
                        <div class="col-sm-6 mb-3 mb-sm-0">
                            <div class="form-group {{ $errors->has('firstName') ? 'has-error' : '' }}"> 
                                <input type="text" name="name" class="form-control" id="name" placeholder="Name" value="{{$data['name']}}" required>
                                <span class="text-danger">{{ $errors->first('firstName') }}</span>
                            </div>
                        </div>
                        <div class="col-sm-6 mb-3 mb-sm-0">
                            <div class="form-group {{ $errors->has('email') ? 'has-error' : '' }}"> 
                                <input type="text" class="form-control" id="country" placeholder="Country" value="{{$data['country']}}" name="country" required>
                                <span class="text-danger">{{ $errors->first('email') }}</span>
                            </div>
                        </div>
                    </div>
                    <div class="form-group row">
                        <div class="col-sm-6">
                            <div class="form-group {{ $errors->has('employeeId') ? 'has-error' : '' }}">
                                <input type="date" class="form-control" id="date" placeholder="Date" name="employeeId" required>
                                <span class="text-danger">{{ $errors->first('employeeId') }}</span>
                            </div>
                        </div>
                        <div class="col-sm-6 mb-3 mb-sm-0">
                            <div class="form-group {{ $errors->has('email') ? 'has-error' : '' }}"> 
                                <input type="text" class="form-control" id="address" placeholder="Address" name="country" required>
                                <span class="text-danger">{{ $errors->first('email') }}</span>
                            </div>
                        </div>
                    </div>
                    <div class="form-group row">
                        <div class="col-sm-6 mb-3 mb-sm-0">
                            <div class="form-group {{ $errors->has('employeeId') ? 'has-error' : '' }}">
                                <input type="text" class="form-control" id="terms_of_delivery" placeholder="Terms of Delivery" name="terms_of_delivery" required>
                                <span class="text-danger">{{ $errors->first('employeeId') }}</span>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group {{ $errors->has('employeeId') ? 'has-error' : '' }}">
                                <input type="text" class="form-control" id="payment_term" placeholder="Payment Term" name="payment_term" required>
                                <span class="text-danger">{{ $errors->first('employeeId') }}</span>
                            </div>
                        </div>
                    </div>
                    <div class="form-group row">
                        <div class="col-md-6">
                            <select class="form-control" name="mode_of_payment" id="mode_of_payment" required>
                                <option value="">Select Mode of Payment</option>
                                <option value="Wire Transfer">Wire Transfer</option>
                                <option value="Paypal">Paypal</option>
                                <option value="Credit Card">Credit Card</option>
                                <option value="Debit Card">Debit Card</option>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <select class="form-control" name="payment_status" id="payment_status" required>
                                <option value="">Select Payment Status</option>
                                <option value="Success">Success</option>
                                <option value="Pending">Pending</option>
                                <option value="Failed">Failed</option>
                            </select>
                        </div>
                    </div>
                    <hr class="border-secondary">
                    <div class="form-group row">
                        <div class="col-sm-6">
                            <div class="form-group {{ $errors->has('employeeId') ? 'has-error' : '' }}">
                                <input type="text" class="form-control" id="report_name" placeholder="Report Name" name="report_name" value="{{$data['report_name']}}" required>
                                <span class="text-danger">{{ $errors->first('employeeId') }}</span>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group {{ $errors->has('employeeId') ? 'has-error' : '' }}">
                                <input type="number" class="form-control" id="unit_price" placeholder="Unit Price" name="unit_price" required>
                                <span class="text-danger">{{ $errors->first('employeeId') }}</span>
                            </div>
                        </div>
                    </div>
                    <div class="form-group row">
                        <div class="col-sm-6">
                            <div class="form-group {{ $errors->has('employeeId') ? 'has-error' : '' }}">
                                <input type="number" class="form-control" id="quantity" placeholder="Quantity" name="quantity" required>
                                <span class="text-danger">{{ $errors->first('employeeId') }}</span>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group {{ $errors->has('employeeId') ? 'has-error' : '' }}">
                                <input type="number" class="form-control" id="total" placeholder="Total" name="total" required>
                                <span class="text-danger">{{ $errors->first('employeeId') }}</span>
                            </div>
                        </div>
                    </div>
                    <select class="form-control col-sm-12" name="mode_of_payment" id="mode_of_payment" required>
                            <option value="">Select License</option>
                            <option value="Single User License">Single User License</option>
                            <option value="Online Only">Online Only</option>
                            <option value="Five User License">Five User License</option>
                            <option value="Enterprise Lincense">Enterprise Lincense</option>
                        </select>
                        <br>
                    <hr class="border-secondary">
                    <button type="submit" class="btn btn-primary btn-block">SUBMIT</button>
                    {{ csrf_field() }}
                </form>
            </div>
        </div>
    </div>
</div>
<link href="{{ asset('css/bootstrap-multiselect.css') }}" rel="stylesheet" type="text/css" />
<script src="{{ asset('js/bootstrap-multiselect.min.js') }}" type="application/javascript"></script>
<script type="application/javascript">
$(function () {
    $('#regionsList').multiselect({
        includeSelectAllOption: true
    });
});
$(function () {
    $('#categoriesList').multiselect({
        includeSelectAllOption: true,
    });
});
</script>
@endsection